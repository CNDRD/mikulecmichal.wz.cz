﻿using System;
using System.Threading;

namespace ConsoleApp8
{
    class Program
    {
        static void Main()
        {
			Console.Title = "Michal Mikulec";
			Console.CursorVisible = false;
			Console.Clear();
			Console.SetWindowSize(100, 30);

			
			Trida t = new Trida();
            t.DoTheThing();
            Console.Read();
        }
    }
    class Trida
    {
        public void DoTheThing()
        {
			var amogus = new[]
			{
				@"        _      _           _          _ _          _           ",
				@"  /\/\ (_) ___| |__   __ _| |   /\/\ (_) | ___   _| | ___  ___ ",
				@" /    \| |/ __| '_ \ / _` | |  /    \| | |/ / | | | |/ _ \/ __|",
				@"/ /\/\ \ | (__| | | | (_| | | / /\/\ \ |   <| |_| | |  __/ (__ ",
				@"\/    \/_|\___|_| |_|\__,_|_| \/    \/_|_|\_\\__,_|_|\___|\___|"
			};

			for (int poop = 0; poop < ((Console.WindowHeight / 2) - (amogus.Length / 2)); poop++)
			{
				for (int xd = 0; xd < amogus.Length; xd++)
				{
					string sus = amogus[xd];
					int calcWidth = (Console.WindowWidth / 2) - (sus.Length / 2);
					int calcHeight = (poop + xd);
					Console.SetCursorPosition(calcWidth, calcHeight);
					Console.Write(sus);
				}
				Thread.Sleep(200);
				Console.Clear();
			}

            for (int i = 0; i < 10; i++)
            {
                if (i % 2 == 0) { Console.ForegroundColor = ConsoleColor.Cyan; }
                else { Console.ForegroundColor = ConsoleColor.Green; }

				for(int xd = 0; xd < amogus.Length; xd++)
				{
					string sus = amogus[xd];
					int calcWidth = (Console.WindowWidth / 2) - (sus.Length / 2);
					int calcHeight = (Console.WindowHeight / 2) - (amogus.Length / 2) + xd;
					Console.SetCursorPosition(calcWidth, calcHeight);
					Console.Write(sus);
				}

				Thread.Sleep(1000);
				Console.Clear();

			}
        }
    }
}